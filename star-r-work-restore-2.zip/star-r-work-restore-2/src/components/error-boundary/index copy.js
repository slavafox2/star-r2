import ErrorBoundary from './error-boundary';

export default ErrorBoundary;
