import PeoplePage from "./people-page";
import PlanetPage from "./planet-page";
import StarshipPage from "./starship-page";
import LoginPage from "./login-page";
import SecretPage from "./secret-page";

export { PeoplePage, PlanetPage, StarshipPage, LoginPage, SecretPage };
