import React from "react";
import "./spinner.css";

const Spinner = () => {
  return (
    <div className="loadingio-spinner-ball-ynp4er771op">
      <div className="ldio-0amldnzb408">
        <div></div>
      </div>
    </div>
  );
};

export default Spinner;
